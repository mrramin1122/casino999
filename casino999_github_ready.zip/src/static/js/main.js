// Main JavaScript for Casino999

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Auto-refresh chat messages every 10 seconds if on chat page
    if (document.querySelector('.chat-messages')) {
        setInterval(refreshChatMessages, 10000);
    }

    // Initialize slot machine if on slot game page
    if (document.querySelector('.slot-machine')) {
        initializeSlotMachine();
    }

    // Initialize roulette if on roulette game page
    if (document.querySelector('.roulette-wheel')) {
        initializeRoulette();
    }
});

// Chat functions
function refreshChatMessages() {
    fetch('/api/chat/messages')
        .then(response => response.json())
        .then(data => {
            const chatMessages = document.querySelector('.chat-messages');
            if (!chatMessages) return;
            
            let messagesHTML = '';
            data.forEach(msg => {
                const isOwn = msg.username === currentUsername;
                messagesHTML += `
                    <div class="message ${isOwn ? 'own' : ''}">
                        <div class="message-info">
                            <span class="message-author">${msg.username}</span>
                            <span class="message-time">${msg.timestamp}</span>
                        </div>
                        <div class="message-content">
                            ${msg.message}
                        </div>
                    </div>
                `;
            });
            
            chatMessages.innerHTML = messagesHTML;
            chatMessages.scrollTop = chatMessages.scrollHeight;
        })
        .catch(error => console.error('Error fetching chat messages:', error));
}

// Slot machine functions
function initializeSlotMachine() {
    const spinButton = document.getElementById('spin-button');
    const betAmount = document.getElementById('bet-amount');
    const resultDisplay = document.getElementById('game-result');
    
    if (!spinButton) return;
    
    spinButton.addEventListener('click', function() {
        const amount = parseFloat(betAmount.value);
        if (isNaN(amount) || amount <= 0) {
            alert('Zəhmət olmasa düzgün məbləğ daxil edin.');
            return;
        }
        
        // Disable button during spin
        spinButton.disabled = true;
        spinButton.textContent = 'Fırlanır...';
        
        // Show spinning animation
        const reels = document.querySelectorAll('.slot-reel');
        reels.forEach(reel => {
            reel.classList.add('spinning');
        });
        
        // Send spin request to server
        fetch('/api/games/slot/spin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ bet_amount: amount }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
                return;
            }
            
            // Update reels with result
            for (let i = 0; i < reels.length; i++) {
                const symbols = reels[i].querySelectorAll('.slot-symbol');
                for (let j = 0; j < symbols.length; j++) {
                    symbols[j].textContent = data.result[i][j];
                }
            }
            
            // Remove spinning animation
            setTimeout(() => {
                reels.forEach(reel => {
                    reel.classList.remove('spinning');
                });
                
                // Update result display
                if (data.win_amount > 0) {
                    resultDisplay.innerHTML = `
                        <div class="win-message">Təbrik edirik! ${data.win_amount} AZN qazandınız!</div>
                        <div>Qazanc xətləri: ${data.win_lines.join(', ')}</div>
                    `;
                } else {
                    resultDisplay.innerHTML = `
                        <div class="lose-message">Təəssüf! Bu dəfə qazanmadınız.</div>
                        <div>Yenidən cəhd edin!</div>
                    `;
                }
                
                // Update balance display
                document.querySelector('.balance-amount').textContent = `${data.new_balance} AZN`;
                
                // Re-enable button
                spinButton.disabled = false;
                spinButton.textContent = 'Fırlat';
            }, 1000);
        })
        .catch(error => {
            console.error('Error spinning slot:', error);
            spinButton.disabled = false;
            spinButton.textContent = 'Fırlat';
        });
    });
}

// Roulette functions
function initializeRoulette() {
    const spinButton = document.getElementById('spin-button');
    const betAmount = document.getElementById('bet-amount');
    const betOptions = document.querySelectorAll('.bet-option');
    const resultDisplay = document.getElementById('game-result');
    const rouletteWheel = document.querySelector('.roulette-wheel');
    
    if (!spinButton || !betOptions.length) return;
    
    // Set up bet options
    let selectedBetType = null;
    let selectedBetValue = null;
    
    betOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove active class from all options
            betOptions.forEach(opt => opt.classList.remove('active'));
            
            // Add active class to selected option
            this.classList.add('active');
            
            // Store selected bet
            selectedBetType = this.dataset.type;
            selectedBetValue = this.dataset.value;
        });
    });
    
    // Set up spin button
    spinButton.addEventListener('click', function() {
        const amount = parseFloat(betAmount.value);
        
        if (isNaN(amount) || amount <= 0) {
            alert('Zəhmət olmasa düzgün məbləğ daxil edin.');
            return;
        }
        
        if (!selectedBetType || !selectedBetValue) {
            alert('Zəhmət olmasa mərc seçin.');
            return;
        }
        
        // Disable button during spin
        spinButton.disabled = true;
        spinButton.textContent = 'Fırlanır...';
        
        // Show spinning animation
        rouletteWheel.classList.add('spinning');
        
        // Send spin request to server
        fetch('/api/games/roulette/spin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                bet_type: selectedBetType,
                bet_value: selectedBetValue,
                bet_amount: amount
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert(data.error);
                return;
            }
            
            // Update wheel with result
            setTimeout(() => {
                rouletteWheel.classList.remove('spinning');
                
                // Show result number
                rouletteWheel.setAttribute('data-result', data.result);
                
                // Update result display
                if (data.win) {
                    resultDisplay.innerHTML = `
                        <div class="win-message">Təbrik edirik! ${data.win_amount} AZN qazandınız!</div>
                        <div>Nəticə: ${data.result}</div>
                    `;
                } else {
                    resultDisplay.innerHTML = `
                        <div class="lose-message">Təəssüf! Bu dəfə qazanmadınız.</div>
                        <div>Nəticə: ${data.result}</div>
                    `;
                }
                
                // Update balance display
                document.querySelector('.balance-amount').textContent = `${data.new_balance} AZN`;
                
                // Re-enable button
                spinButton.disabled = false;
                spinButton.textContent = 'Fırlat';
            }, 2000);
        })
        .catch(error => {
            console.error('Error spinning roulette:', error);
            spinButton.disabled = false;
            spinButton.textContent = 'Fırlat';
        });
    });
}
