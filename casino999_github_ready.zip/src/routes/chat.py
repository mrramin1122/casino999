from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from src.models.chat import ChatMessage
from src.models.user import User
from src.main import db
from datetime import datetime

chat_bp = Blueprint('chat', __name__)

@chat_bp.route('/chat')
@login_required
def chat():
    messages = ChatMessage.query.filter_by(is_public=True).order_by(ChatMessage.created_at.desc()).limit(50).all()
    messages.reverse()  # Show oldest messages first
    return render_template('chat/chat.html', messages=messages)

@chat_bp.route('/chat/send', methods=['POST'])
@login_required
def send_message():
    message_text = request.form.get('message')
    
    if not message_text or message_text.strip() == '':
        flash('Boş mesaj göndərilə bilməz.', 'danger')
        return redirect(url_for('chat.chat'))
    
    new_message = ChatMessage(
        user_id=current_user.id,
        message=message_text,
        is_public=True
    )
    
    db.session.add(new_message)
    db.session.commit()
    
    return redirect(url_for('chat.chat'))

@chat_bp.route('/api/chat/messages')
@login_required
def get_messages():
    messages = ChatMessage.query.filter_by(is_public=True).order_by(ChatMessage.created_at.desc()).limit(50).all()
    messages.reverse()
    
    message_list = []
    for msg in messages:
        user = User.query.get(msg.user_id)
        message_list.append({
            'id': msg.id,
            'username': user.username,
            'message': msg.message,
            'timestamp': msg.created_at.strftime('%H:%M:%S')
        })
    
    return jsonify(message_list)

@chat_bp.route('/support')
@login_required
def support():
    messages = ChatMessage.query.filter_by(
        user_id=current_user.id, 
        is_public=False
    ).order_by(ChatMessage.created_at.desc()).limit(50).all()
    messages.reverse()
    
    return render_template('chat/support.html', messages=messages)

@chat_bp.route('/support/send', methods=['POST'])
@login_required
def send_support_message():
    message_text = request.form.get('message')
    
    if not message_text or message_text.strip() == '':
        flash('Boş mesaj göndərilə bilməz.', 'danger')
        return redirect(url_for('chat.support'))
    
    new_message = ChatMessage(
        user_id=current_user.id,
        message=message_text,
        is_public=False
    )
    
    db.session.add(new_message)
    db.session.commit()
    
    flash('Mesajınız dəstək komandasına göndərildi.', 'success')
    return redirect(url_for('chat.support'))
