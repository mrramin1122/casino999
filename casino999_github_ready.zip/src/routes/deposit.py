from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from src.models.transaction import Transaction
from src.models.user import User
from src.main import db
from datetime import datetime

deposit_bp = Blueprint('deposit', __name__)

@deposit_bp.route('/deposit')
@login_required
def deposit():
    transactions = Transaction.query.filter_by(
        user_id=current_user.id
    ).order_by(Transaction.created_at.desc()).limit(10).all()
    
    return render_template('deposit/deposit.html', transactions=transactions)

@deposit_bp.route('/deposit/add', methods=['POST'])
@login_required
def add_deposit():
    amount = request.form.get('amount')
    payment_method = request.form.get('payment_method')
    
    try:
        amount = float(amount)
        if amount <= 0:
            flash('Məbləğ müsbət olmalıdır.', 'danger')
            return redirect(url_for('deposit.deposit'))
    except ValueError:
        flash('Düzgün məbləğ daxil edin.', 'danger')
        return redirect(url_for('deposit.deposit'))
    
    # Create new transaction
    new_transaction = Transaction(
        user_id=current_user.id,
        amount=amount,
        transaction_type='deposit',
        status='pending'
    )
    
    db.session.add(new_transaction)
    db.session.commit()
    
    # In a real application, this would redirect to a payment gateway
    # For demo purposes, we'll simulate a successful payment
    flash(f'{amount} AZN məbləğində depozit sorğunuz qəbul edildi. Ödəniş təsdiqlənir...', 'success')
    
    # Simulate payment processing
    return redirect(url_for('deposit.process_payment', transaction_id=new_transaction.id))

@deposit_bp.route('/deposit/process/<int:transaction_id>')
@login_required
def process_payment(transaction_id):
    transaction = Transaction.query.get_or_404(transaction_id)
    
    # Ensure the transaction belongs to the current user
    if transaction.user_id != current_user.id:
        flash('İcazəsiz əməliyyat.', 'danger')
        return redirect(url_for('deposit.deposit'))
    
    # In a real application, this would check the payment gateway status
    # For demo purposes, we'll simulate a successful payment
    transaction.status = 'completed'
    current_user.balance += transaction.amount
    
    db.session.commit()
    
    flash(f'{transaction.amount} AZN məbləğində depozit uğurla tamamlandı!', 'success')
    return redirect(url_for('deposit.deposit'))

@deposit_bp.route('/withdraw')
@login_required
def withdraw():
    transactions = Transaction.query.filter_by(
        user_id=current_user.id, 
        transaction_type='withdrawal'
    ).order_by(Transaction.created_at.desc()).limit(10).all()
    
    return render_template('deposit/withdraw.html', transactions=transactions)

@deposit_bp.route('/withdraw/request', methods=['POST'])
@login_required
def request_withdrawal():
    amount = request.form.get('amount')
    
    try:
        amount = float(amount)
        if amount <= 0:
            flash('Məbləğ müsbət olmalıdır.', 'danger')
            return redirect(url_for('deposit.withdraw'))
    except ValueError:
        flash('Düzgün məbləğ daxil edin.', 'danger')
        return redirect(url_for('deposit.withdraw'))
    
    # Check if user has enough balance
    if current_user.balance < amount:
        flash('Balansınız kifayət qədər deyil.', 'danger')
        return redirect(url_for('deposit.withdraw'))
    
    # Create new transaction
    new_transaction = Transaction(
        user_id=current_user.id,
        amount=amount,
        transaction_type='withdrawal',
        status='pending'
    )
    
    # Update user balance
    current_user.balance -= amount
    
    db.session.add(new_transaction)
    db.session.commit()
    
    flash(f'{amount} AZN məbləğində çıxarış sorğunuz qəbul edildi. Sorğu işlənir...', 'success')
    return redirect(url_for('deposit.withdraw'))
