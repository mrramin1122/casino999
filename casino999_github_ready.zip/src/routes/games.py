from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from src.models.game import Game
from src.models.user import User
from src.main import db
import random

games_bp = Blueprint('games', __name__)

@games_bp.route('/games')
@login_required
def games_list():
    games = Game.query.filter_by(is_active=True).all()
    return render_template('games/games_list.html', games=games)

@games_bp.route('/games/<int:game_id>')
@login_required
def play_game(game_id):
    game = Game.query.get_or_404(game_id)
    return render_template(f'games/{game.game_type}_game.html', game=game)

@games_bp.route('/api/games/slot/spin', methods=['POST'])
@login_required
def slot_spin():
    bet_amount = request.json.get('bet_amount', 1.0)
    
    try:
        bet_amount = float(bet_amount)
        if bet_amount <= 0:
            return jsonify({'error': 'Məbləğ müsbət olmalıdır.'}), 400
    except ValueError:
        return jsonify({'error': 'Düzgün məbləğ daxil edin.'}), 400
    
    # Check if user has enough balance
    if current_user.balance < bet_amount:
        return jsonify({'error': 'Balansınız kifayət qədər deyil.'}), 400
    
    # Deduct bet amount from user balance
    current_user.balance -= bet_amount
    
    # Generate random slot results
    symbols = ['🍒', '🍊', '🍋', '🍇', '🍉', '💎', '7️⃣']
    weights = [20, 20, 20, 15, 15, 5, 5]  # Probability weights
    
    result = []
    for i in range(3):  # 3 reels
        row = []
        for j in range(3):  # 3 symbols per reel
            symbol = random.choices(symbols, weights=weights)[0]
            row.append(symbol)
        result.append(row)
    
    # Check for wins
    win_amount = 0
    win_lines = []
    
    # Check horizontal lines
    for i in range(3):
        if result[i][0] == result[i][1] == result[i][2]:
            win_lines.append(f'Horizontal {i+1}')
            multiplier = get_symbol_multiplier(result[i][0])
            win_amount += bet_amount * multiplier
    
    # Check vertical lines
    for i in range(3):
        if result[0][i] == result[1][i] == result[2][i]:
            win_lines.append(f'Vertical {i+1}')
            multiplier = get_symbol_multiplier(result[0][i])
            win_amount += bet_amount * multiplier
    
    # Check diagonals
    if result[0][0] == result[1][1] == result[2][2]:
        win_lines.append('Diagonal 1')
        multiplier = get_symbol_multiplier(result[0][0])
        win_amount += bet_amount * multiplier
    
    if result[0][2] == result[1][1] == result[2][0]:
        win_lines.append('Diagonal 2')
        multiplier = get_symbol_multiplier(result[0][2])
        win_amount += bet_amount * multiplier
    
    # Add win amount to user balance
    current_user.balance += win_amount
    db.session.commit()
    
    return jsonify({
        'result': result,
        'bet_amount': bet_amount,
        'win_amount': win_amount,
        'win_lines': win_lines,
        'new_balance': current_user.balance
    })

def get_symbol_multiplier(symbol):
    multipliers = {
        '🍒': 2,
        '🍊': 2,
        '🍋': 2,
        '🍇': 3,
        '🍉': 3,
        '💎': 5,
        '7️⃣': 10
    }
    return multipliers.get(symbol, 1)

@games_bp.route('/api/games/roulette/spin', methods=['POST'])
@login_required
def roulette_spin():
    bet_type = request.json.get('bet_type')
    bet_value = request.json.get('bet_value')
    bet_amount = request.json.get('bet_amount', 1.0)
    
    try:
        bet_amount = float(bet_amount)
        if bet_amount <= 0:
            return jsonify({'error': 'Məbləğ müsbət olmalıdır.'}), 400
    except ValueError:
        return jsonify({'error': 'Düzgün məbləğ daxil edin.'}), 400
    
    # Check if user has enough balance
    if current_user.balance < bet_amount:
        return jsonify({'error': 'Balansınız kifayət qədər deyil.'}), 400
    
    # Deduct bet amount from user balance
    current_user.balance -= bet_amount
    
    # Generate random roulette result (0-36)
    result = random.randint(0, 36)
    
    # Determine if bet wins
    win = False
    win_amount = 0
    
    if bet_type == 'number' and int(bet_value) == result:
        win = True
        win_amount = bet_amount * 35
    elif bet_type == 'color':
        red_numbers = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]
        if (bet_value == 'red' and result in red_numbers) or (bet_value == 'black' and result not in red_numbers and result != 0):
            win = True
            win_amount = bet_amount * 2
    elif bet_type == 'even_odd':
        if (bet_value == 'even' and result % 2 == 0 and result != 0) or (bet_value == 'odd' and result % 2 == 1):
            win = True
            win_amount = bet_amount * 2
    
    # Add win amount to user balance if won
    if win:
        current_user.balance += win_amount
    
    db.session.commit()
    
    return jsonify({
        'result': result,
        'bet_type': bet_type,
        'bet_value': bet_value,
        'bet_amount': bet_amount,
        'win': win,
        'win_amount': win_amount,
        'new_balance': current_user.balance
    })
