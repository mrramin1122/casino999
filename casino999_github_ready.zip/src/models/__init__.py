from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from src.models.user import User
from src.main import db, login_manager

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Import models to ensure they are registered with SQLAlchemy
from src.models.transaction import Transaction
from src.models.chat import ChatMessage
from src.models.game import Game

# Create initial data for the database
def create_initial_data():
    # Check if data already exists
    if Game.query.first() is not None:
        return
    
    # Create sample games
    games = [
        Game(
            name="Fruit Slots",
            description="Klassik meyvə slotları ilə böyük uduşlar qazanın",
            game_type="slot",
            image_url="/static/images/slot-game.jpg"
        ),
        Game(
            name="Diamond Rush",
            description="Parlaq brilyantlarla dolu slot oyunu",
            game_type="slot",
            image_url="/static/images/diamond-slot.jpg"
        ),
        Game(
            name="Jackpot Mania",
            description="Böyük jackpot uduşları ilə həyəcanlı slot oyunu",
            game_type="slot",
            image_url="/static/images/jackpot-slot.jpg"
        ),
        Game(
            name="Rulet",
            description="Həyəcanverici rulet oyunu ilə şansınızı sınayın",
            game_type="roulette",
            image_url="/static/images/roulette-game.jpg"
        ),
        Game(
            name="Blackjack",
            description="Strategiya və şans oyunu",
            game_type="card",
            image_url="/static/images/blackjack-game.jpg"
        ),
        Game(
            name="Poker",
            description="Dünyanın ən populyar kart oyunu",
            game_type="card",
            image_url="/static/images/poker-game.jpg"
        ),
        Game(
            name="Canlı Rulet",
            description="Həqiqi dilerlərlə canlı rulet oyunu",
            game_type="live",
            image_url="/static/images/live-roulette.jpg"
        ),
        Game(
            name="Canlı Blackjack",
            description="Həqiqi dilerlərlə canlı blackjack oyunu",
            game_type="live",
            image_url="/static/images/live-blackjack.jpg"
        ),
        Game(
            name="Canlı Baccarat",
            description="Həqiqi dilerlərlə canlı baccarat oyunu",
            game_type="live",
            image_url="/static/images/live-baccarat.jpg"
        )
    ]
    
    for game in games:
        db.session.add(game)
    
    db.session.commit()
